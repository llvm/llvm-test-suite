#!/bin/sh
sed -re 's/clamav-[^ \n,]*/clamav-TMPFILE/g' -e 's/0x[0-9a-f]+/0xADDR/g' -e 's/Setting.*encoding.*to/SETENC/g' -e 's/.*iconv.*/ICONVMSG/g' -e 's/New.*encoding.*:/NEWENC/g' -e 's/\(nil\)/0/g' $1 >tmp_reference
sed -re 's/clamav-[^ \n,]*/clamav-TMPFILE/g' -e 's/0x[0-9a-f]+/0xADDR/g' -e 's/Setting.*encoding.*to/SETENC/g' -e 's/.*iconv.*/ICONVMSG/g' -e 's/New.*encoding.*:/NEWENC/g' -e 's/\(nil\)/0/g' $2 >tmp_new
diff -u tmp_reference tmp_new  >/dev/null
exit $?
